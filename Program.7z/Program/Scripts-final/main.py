import os, time, random, subprocess, glob, re
import pyautogui, pygetwindow as gw
import ctypes

# ==================================================================================
# FLEXIBLE WINDOW AUTOMATION SYSTEM - CONFIGURATION SECTION
# ==================================================================================
# This system allows you to automate ANY Windows application by modifying the 
# settings below. Simply change the target application and customize the key 
# sequences to match your needs.
# ==================================================================================

# ---------- TARGET APPLICATION CONFIGURATION ----------
# MODIFY THESE VALUES TO CHANGE WHICH APPLICATION TO AUTOMATE:

# 1. APPLICATION TO LAUNCH AND AUTOMATE
# Change this to any Windows executable you want to automate
# Examples:
#   "calc.exe"           - Windows Calculator
#   "notepad.exe"        - Windows Notepad
#   "mspaint.exe"        - Microsoft Paint
#   "winword.exe"        - Microsoft Word
#   "excel.exe"          - Microsoft Excel
#   "chrome.exe"         - Google Chrome
#   "firefox.exe"        - Mozilla Firefox
TARGET_APP = "calc.exe"

# 2. WINDOW TITLE TO SEARCH FOR
# This is the title that appears in the window's title bar
# The script will look for windows containing this text
# Examples:
#   "Calculator"         - For Windows Calculator
#   "Notepad"           - For Windows Notepad  
#   "Paint"             - For Microsoft Paint
#   "Microsoft Word"     - For Microsoft Word
#   "Google Chrome"      - For Google Chrome
#   "Mozilla Firefox"    - For Mozilla Firefox
TARGET_WINDOW_TITLE = "Calculator"

# 3. KEY SEQUENCES TO SEND TO THE APPLICATION
# Define what keys/text should be sent to the target application
# This is a list of dictionaries, each representing an action
# Supported action types:
#   "text" - Types the specified text
#   "key" - Presses a single key or key combination
#   "hotkey" - Presses multiple keys simultaneously
#   "wait" - Waits for specified seconds
# 
# EXAMPLES FOR DIFFERENT APPLICATIONS:
# 
# For Calculator (current setup):
KEY_SEQUENCES = [
    {"action": "hotkey", "keys": ["ctrl", "a"], "description": "Select all"},
    {"action": "key", "keys": "backspace", "description": "Clear field"},
    {"action": "text", "keys": "RANDOM_NUMBER", "description": "Type random number"},
    {"action": "wait", "keys": 0.5, "description": "Wait for UI update"}
]

# For Notepad example (uncomment to use):
# KEY_SEQUENCES = [
#     {"action": "text", "keys": "Hello, this is automated text!", "description": "Type greeting"},
#     {"action": "key", "keys": "enter", "description": "New line"},
#     {"action": "text", "keys": "RANDOM_NUMBER", "description": "Type random number"},
#     {"action": "key", "keys": "enter", "description": "New line"},
#     {"action": "text", "keys": "Automation complete!", "description": "Type completion message"}
# ]

# For Paint example (uncomment to use):
# KEY_SEQUENCES = [
#     {"action": "hotkey", "keys": ["ctrl", "t"], "description": "Open text tool"},
#     {"action": "wait", "keys": 1.0, "description": "Wait for tool selection"},
#     {"action": "text", "keys": "Automated Text: RANDOM_NUMBER", "description": "Type text with random number"}
# ]

# ---------- WINDOW POSITIONING AND SIZING ----------
# Configure how the target window should be positioned and sized
TARGET_WIDTH  = 360          # Width of the target window in pixels
TARGET_HEIGHT = 560          # Height of the target window in pixels
WINDOW_LEFT   = 100          # X position (distance from left edge of screen)
WINDOW_TOP    = 100          # Y position (distance from top edge of screen)

# ---------- TIMING AND BEHAVIOR SETTINGS ----------
OPEN_TIMEOUT  = 8.0          # Maximum time to wait for application to launch (seconds)
TYPE_INTERVAL = 0.05         # Delay between individual keystrokes (seconds)
ACTION_PAUSE  = 0.05         # General pause between pyautogui actions (seconds)
ACTIVATION_DELAY = 0.5       # Time to wait after activating window (seconds)
SCREENSHOT_DELAY = 0.8       # Time to wait before taking screenshot (seconds)

# ---------- OUTPUT CONFIGURATION ----------
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "Output")
SCREENSHOT_PREFIX = "automation"  # Prefix for screenshot filenames

# ==================================================================================
# END OF CONFIGURATION SECTION
# ==================================================================================

# Create output directory if it doesn't exist
os.makedirs(OUTPUT_DIR, exist_ok=True)
pyautogui.PAUSE = ACTION_PAUSE

# ---- Helper function to generate unique, chronological filenames ----
def next_index():
    """
    Get the next available index for screenshot filenames by checking
    existing files in the output directory.
    """
    files = glob.glob(os.path.join(OUTPUT_DIR, f"{SCREENSHOT_PREFIX}_*.png"))
    nums = []
    for f in files:
        m = re.search(rf"{SCREENSHOT_PREFIX}_(\d+)\.png$", os.path.basename(f))
        if m:
            nums.append(int(m.group(1)))
    return (max(nums) + 1) if nums else 1

def next_screenshot_path():
    """
    Generate the next sequential screenshot filename.
    """
    idx = next_index()
    return os.path.join(OUTPUT_DIR, f"{SCREENSHOT_PREFIX}_{idx:05d}.png")

# ---- Window handling functions ----
def get_target_windows():
    """
    Find all visible windows matching the target window title.
    
    Returns:
        List of window objects matching the target title.
    """
    return [w for w in gw.getWindowsWithTitle(TARGET_WINDOW_TITLE) if getattr(w, "visible", True)]

def launch_target_app(existing_hwnds):
    """
    Launch the target application and wait for its window to appear.
    
    Args:
        existing_hwnds: Set of window handles that already exist
                        (to identify the newly created window)
    
    Returns:
        Window object of the newly launched application
    
    Raises:
        RuntimeError: If the application window doesn't appear within the timeout
    """
    print(f"▶ Launching {TARGET_APP}...")
    subprocess.Popen(TARGET_APP, shell=True)  # Use shell=True for better compatibility
    
    t0 = time.time()
    while time.time() - t0 < OPEN_TIMEOUT:
        wins = get_target_windows()
        for w in wins:
            hwnd = getattr(w, "_hWnd", None)
            if hwnd and hwnd not in existing_hwnds:
                # Verify window is actually ready
                try:
                    _ = w.title  # Test if window is accessible
                    time.sleep(0.5)  # Give window time to fully initialize
                    print(f"✅ Window '{w.title}' successfully launched")
                    return w
                except Exception:
                    continue  # Window not ready yet
        time.sleep(0.2)
    
    raise RuntimeError(f"{TARGET_APP} window did not appear within {OPEN_TIMEOUT} seconds.")

def ensure_restored(win):
    """
    Ensure window is not maximized before attempting to resize it.
    
    Args:
        win: Window object to restore if maximized
    """
    try:
        if getattr(win, "isMaximized", False):
            win.restore()
            time.sleep(0.2)
    except Exception:
        pass

def move_resize(win):
    """
    Move and resize window to the configured position and size.
    
    Args:
        win: Window object to move and resize
    """
    try:
        print(f"▶ Positioning window to ({WINDOW_LEFT}, {WINDOW_TOP}) with size {TARGET_WIDTH}x{TARGET_HEIGHT}...")
        ensure_restored(win)
        
        # UWP apps sometimes ignore the first call; do multiple attempts with verification
        for attempt in range(3):
            try:
                win.resizeTo(TARGET_WIDTH, TARGET_HEIGHT)
                time.sleep(0.3)
                win.moveTo(WINDOW_LEFT, WINDOW_TOP)
                time.sleep(0.3)
                
                # Verify the window moved to approximately the right position
                if abs(win.left - WINDOW_LEFT) < 50 and abs(win.top - WINDOW_TOP) < 50:
                    print(f"✅ Window positioned successfully")
                    break
            except Exception as e:
                if attempt == 2:  # Last attempt
                    print(f"⚠️ Failed to position window after 3 attempts: {e}")
                time.sleep(0.2)
    except Exception as e:
        print(f"⚠️ Error in move_resize: {e}")

def is_window_handle_valid(hwnd):
    """
    Check if a window handle is still valid.
    
    Args:
        hwnd: Window handle to check
    
    Returns:
        bool: True if the window handle is valid, False otherwise
    """
    try:
        return bool(ctypes.windll.user32.IsWindow(ctypes.wintypes.HWND(hwnd)))
    except Exception:
        # If ctypes or call fails, assume valid to avoid false negatives
        return True

def activate_window(win):
    """
    Activate window with error handling and verification.
    
    Args:
        win: Window object to activate
    
    Returns:
        bool: True if activation was successful, False otherwise
    """
    win_title = getattr(win, "title", "Unknown")
    win_hwnd = getattr(win, "_hWnd", None)
    
    print(f"▶ Activating window '{win_title}'...")
    
    # First, verify the window still exists and is valid
    if win_hwnd and not is_window_handle_valid(win_hwnd):
        print(f"⚠️ Window handle {win_hwnd} is invalid, trying to find a new window")
        # Try to find a fresh window matching the target title
        target_windows = get_target_windows()
        if target_windows:
            win = target_windows[0]  # Use the first available window
            win_hwnd = getattr(win, "_hWnd", None)
        else:
            print(f"❌ No '{TARGET_WINDOW_TITLE}' windows found!")
            return False
    
    # Try to activate the window
    for attempt in range(3):
        try:
            win.activate()
            time.sleep(ACTIVATION_DELAY)
            
            # Verify activation worked
            active_window = gw.getActiveWindow()
            if active_window and TARGET_WINDOW_TITLE in getattr(active_window, "title", ""):
                print(f"✅ Successfully activated window")
                return True
                
        except Exception as e:
            print(f"⚠️ Activation attempt {attempt+1} failed: {e}")
            time.sleep(0.3)
    
    print(f"❌ Failed to activate window after 3 attempts")
    return False

def get_window_rect_safe(win, attempts=5, delay=0.1):
    """
    Attempt to read window rect with retries to avoid transient errors.
    
    Args:
        win: Window object to get rect from
        attempts: Number of attempts to make
        delay: Delay between attempts in seconds
    
    Returns:
        tuple: (left, top, width, height)
    
    Raises:
        Exception: If all attempts fail
    """
    last_exc = None
    for _ in range(attempts):
        try:
            return (int(win.left), int(win.top), int(win.width), int(win.height))
        except Exception as e:
            last_exc = e
            time.sleep(delay)
    if last_exc:
        raise last_exc

def screenshot_window(win):
    """
    Take a screenshot of the specified window.
    
    Args:
        win: Window object to screenshot
    
    Returns:
        str: Path where the screenshot was saved
    """
    print(f"▶ Taking screenshot of window...")
    
    # Prefer using a fresh handle of the active window to avoid stale HWND issues
    active_window = gw.getActiveWindow()
    target = active_window if (active_window and TARGET_WINDOW_TITLE in getattr(active_window, "title", "")) else win

    # If original handle looks invalid, try to fall back to any visible matching window
    if getattr(target, "_hWnd", None) and not is_window_handle_valid(getattr(target, "_hWnd")):
        candidates = get_target_windows()
        if candidates:
            target = candidates[0]

    region = get_window_rect_safe(target)
    img = pyautogui.screenshot(region=region)
    path = next_screenshot_path()
    img.save(path)
    print(f"💾 Saved screenshot: {path}")
    return path

def close_window(win):
    """
    Close the specified window using Alt+F4.
    
    Args:
        win: Window object to close
    """
    print(f"▶ Closing window...")
    activate_window(win)
    pyautogui.hotkey("alt", "f4")
    time.sleep(0.5)

def generate_random_text():
    """
    Generate random text based on the application context.
    For this example, we're using a random number as in the original script.
    
    Returns:
        str: Random text (number in this case)
    """
    value = random.uniform(1, 250)
    num_str = str(round(value)) if random.choice([True, False]) else f"{value:.2f}"
    return num_str

def execute_key_sequence(sequence):
    """
    Execute a single key sequence action.
    
    Args:
        sequence: Dictionary with action parameters
    
    Returns:
        str: Description of what was done
    """
    action_type = sequence.get("action", "")
    keys = sequence.get("keys", "")
    description = sequence.get("description", "Unknown action")
    
    if action_type == "text":
        # If keys contains RANDOM_NUMBER, replace it with a random number
        if isinstance(keys, str) and "RANDOM_NUMBER" in keys:
            random_text = generate_random_text()
            text_to_type = keys.replace("RANDOM_NUMBER", random_text)
        else:
            text_to_type = keys
        
        pyautogui.typewrite(text_to_type, interval=TYPE_INTERVAL)
        return f"{description}: {text_to_type}"
    
    elif action_type == "key":
        pyautogui.press(keys)
        return f"{description}: Pressed {keys}"
    
    elif action_type == "hotkey":
        if isinstance(keys, list) and len(keys) >= 2:
            pyautogui.hotkey(*keys)
            return f"{description}: Pressed {'+'.join(keys)}"
        else:
            print(f"⚠️ Invalid hotkey format: {keys}")
            return f"Failed to execute hotkey: {keys}"
    
    elif action_type == "wait":
        if isinstance(keys, (int, float)):
            time.sleep(keys)
            return f"{description}: Waited {keys} seconds"
        else:
            print(f"⚠️ Invalid wait time: {keys}")
            return f"Failed to wait: {keys}"
    
    else:
        print(f"⚠️ Unknown action type: {action_type}")
        return f"Unknown action: {action_type}"

def perform_actions_on_window(win):
    """
    Perform all configured key sequences on the specified window.
    
    Args:
        win: Window object to perform actions on
    
    Returns:
        bool: True if actions were performed successfully, False otherwise
    """
    print(f"▶ Performing configured actions on window...")
    
    if not activate_window(win):
        print(f"❌ Failed to activate window, cannot perform actions")
        return False
    
    # Execute each action in the key sequence
    for i, sequence in enumerate(KEY_SEQUENCES, 1):
        try:
            result = execute_key_sequence(sequence)
            print(f"  ✓ Action {i}/{len(KEY_SEQUENCES)}: {result}")
            time.sleep(0.2)  # Small pause between actions
        except Exception as e:
            print(f"  ❌ Error executing action {i}/{len(KEY_SEQUENCES)}: {e}")
    
    # Wait a moment before taking the screenshot
    time.sleep(SCREENSHOT_DELAY)
    screenshot_path = screenshot_window(win)
    
    return True

def main():
    """
    Main function that orchestrates the window automation process.
    """
    try:
        # Step 1: Find existing windows to compare against
        existing_windows = set(getattr(w, "_hWnd", None) for w in get_target_windows())
        
        # Step 2: Launch the target application
        target_window = launch_target_app(existing_windows)
        
        # Step 3: Position and resize the window
        move_resize(target_window)
        
        # Step 4: Perform actions on the window and take screenshot
        perform_actions_on_window(target_window)
        
        # Step 5: Close the window (optional, comment out if you want to leave it open)
        close_window(target_window)
        
        print("✅ Automation completed successfully!")
        
    except Exception as e:
        print(f"❌ Error during automation: {e}")

if __name__ == "__main__":
    main()
