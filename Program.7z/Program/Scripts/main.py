import os, time, random, subprocess, glob, re
import pyautogui, pygetwindow as gw
import ctypes

# ---------- SETTINGS ----------
APP = "calc.exe"
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "Output")

# Compact size you wanted
TARGET_WIDTH  = 360
TARGET_HEIGHT = 560
GAP_X         = 5            # horizontal gap between calculators

SCREEN_WIDTH  = 2560         # 2K width
TOP_POS       = 0
OPEN_TIMEOUT  = 8.0          # give UWP time to appear
TYPE_DECIMALS = 2
TYPE_INTERVAL = 0.05         # per-char delay
PAUSE = 0.05                 # pyautogui action pause
# ------------------------------

os.makedirs(OUTPUT_DIR, exist_ok=True)
pyautogui.PAUSE = PAUSE

# ---- unique, chronological filenames ----
def next_index():
    files = glob.glob(os.path.join(OUTPUT_DIR, "calc_*.png"))
    nums = []
    for f in files:
        m = re.search(r"calc_(\d+)\.png$", os.path.basename(f))
        if m:
            nums.append(int(m.group(1)))
    return (max(nums) + 1) if nums else 1

def next_screenshot_path():
    idx = next_index()
    return os.path.join(OUTPUT_DIR, f"calc_{idx:05d}.png")
# -----------------------------------------

def visible_calcs():
    return [w for w in gw.getWindowsWithTitle("Calculator") if getattr(w, "visible", True)]

def launch_new_calc(existing_hwnds):
    """Launch calculator and wait for it to appear with better detection."""
    subprocess.Popen(APP, shell=True)  # Use shell=True for better compatibility
    t0 = time.time()
    while time.time() - t0 < OPEN_TIMEOUT:
        wins = visible_calcs()
        for w in wins:
            hwnd = getattr(w, "_hWnd", None)
            if hwnd and hwnd not in existing_hwnds:
                # Verify window is actually ready
                try:
                    _ = w.title  # Test if window is accessible
                    time.sleep(0.5)  # Give window time to fully initialize
                    return w
                except Exception:
                    continue  # Window not ready yet
        time.sleep(0.2)
    raise RuntimeError("Calculator window did not appear in time.")

def ensure_restored(win):
    try:
        if getattr(win, "isMaximized", False):
            win.restore(); time.sleep(0.2)
    except Exception:
        pass

def move_resize(win, left_pos, top_pos):
    """Move and resize window with error handling and verification."""
    try:
        ensure_restored(win)
        # UWP sometimes ignores the first call; do multiple attempts with verification
        for attempt in range(3):
            try:
                win.resizeTo(TARGET_WIDTH, TARGET_HEIGHT)
                time.sleep(0.3)
                win.moveTo(left_pos, top_pos)
                time.sleep(0.3)
                
                # Verify the window moved to approximately the right position
                if abs(win.left - left_pos) < 50 and abs(win.top - TOP_POS) < 50:
                    break
            except Exception as e:
                if attempt == 2:  # Last attempt
                    print(f"⚠️ Failed to position window after 3 attempts: {e}")
                time.sleep(0.2)
    except Exception as e:
        print(f"⚠️ Error in move_resize: {e}")

def activate_window(win):
    """Activate window with better error handling and verification."""
    win_title = getattr(win, "title", "Unknown")
    win_hwnd = getattr(win, "_hWnd", None)
    
    # First, verify the window still exists and is valid
    if win_hwnd and not _is_window_handle_valid(win_hwnd):
        print(f"    ⚠️ Window handle {win_hwnd} is invalid, trying to find fresh calculator window")
        # Try to find a fresh calculator window
        calcs = visible_calcs()
        if calcs:
            win = calcs[0]  # Use the first available calculator
            win_hwnd = getattr(win, "_hWnd", None)
        else:
            print(f"    ❌ No calculator windows found!")
            return False
    
    # Try to activate the window
    for attempt in range(3):
        try:
            win.activate()
            time.sleep(0.2)
            
            # Verify activation worked
            aw = gw.getActiveWindow()
            if aw and getattr(aw, "title", "").startswith("Calculator"):
                print(f"    ✅ Successfully activated calculator window")
                return True
                
        except Exception as e:
            print(f"    ⚠️ Activation attempt {attempt+1} failed: {e}")
            time.sleep(0.3)
    
    print(f"    ❌ Failed to activate window after 3 attempts")
    return False

def type_random_number():
    """Random number 1–250, sometimes int, sometimes 2‑dec float."""
    value = random.uniform(1, 250)
    num_str = str(round(value)) if random.choice([True, False]) else f"{value:.2f}"
    # clear field reliably, then type
    pyautogui.hotkey("ctrl", "a")
    pyautogui.press("backspace")
    pyautogui.typewrite(num_str, interval=TYPE_INTERVAL)
    return num_str

def _is_window_handle_valid(hwnd: int) -> bool:
    try:
        return bool(ctypes.windll.user32.IsWindow(ctypes.wintypes.HWND(hwnd)))
    except Exception:
        # If ctypes or call fails, assume valid to avoid false negatives
        return True

def _get_window_rect_safe(win, attempts: int = 5, delay: float = 0.1):
    """Attempt to read window rect with retries to avoid transient Invalid window handle errors."""
    last_exc = None
    for _ in range(attempts):
        try:
            return (int(win.left), int(win.top), int(win.width), int(win.height))
        except Exception as e:
            last_exc = e
            time.sleep(delay)
    if last_exc:
        raise last_exc

def screenshot_window(win):
    # Prefer using a fresh handle of the active window right after activation to avoid stale HWND issues.
    aw = gw.getActiveWindow()
    target = aw if (aw and getattr(aw, "title", "").startswith("Calculator")) else win

    # If original handle looks invalid, try to fall back to any visible Calculator window
    if getattr(target, "_hWnd", None) and not _is_window_handle_valid(getattr(target, "_hWnd")):
        cands = visible_calcs()
        if cands:
            target = cands[0]

    region = _get_window_rect_safe(target)
    img = pyautogui.screenshot(region=region)
    path = next_screenshot_path()
    img.save(path)
    print(f"💾 Saved screenshot: {path}")

def close_window(win):
    activate_window(win)
    pyautogui.hotkey("alt", "f4")
    time.sleep(0.35)

def main():
    # 1) Launch all three first
    opened = []
    existing = {w._hWnd for w in visible_calcs()}
    for i in range(3):
        print(f"▶ Launching Calculator #{i+1}…")
        w = launch_new_calc(existing)
        opened.append(w)
        existing.add(w._hWnd)

    # 2) Line them up horizontally from right to left starting from the right edge
    print("▶ Positioning calculators from right to left...")
    for i, w in enumerate(opened):
        # Position from right to left: start from right edge, move left with each calculator
        left_pos = SCREEN_WIDTH - (i + 1) * TARGET_WIDTH - i * GAP_X
        print(f"  └ Calculator #{i+1} at position {left_pos}")
        move_resize(w, left_pos, TOP_POS)
        time.sleep(0.5)  # Extra time between positioning operations

    # 3) Process each one: activate → type → screenshot (keep all open)
    print("▶ Processing calculators (keeping all open)...")
    processed_screenshots = []
    
    for i, w in enumerate(opened, start=1):
        print(f"  └ Processing Calculator #{i}…")
                
        try:
            # Activate with better error handling
            if not activate_window(w):
                print(f"    ❌ Failed to activate Calculator #{i}, skipping...")
                continue
                
            time.sleep(0.5)  # Longer delay to ensure window is fully active
            typed = type_random_number()
            print(f"    📝 Typed: {typed}")
            time.sleep(0.8)  # More time for UI update
            screenshot_window(w)
            processed_screenshots.append((i, w))
            print(f"    ✓ Successfully processed Calculator #{i}")
        except Exception as e:
            print(f"    ⚠️ Error processing Calculator #{i}: {e}")
            
    # 4) Close all calculators at the end
    print("▶ Closing all calculators...")
    for i, w in processed_screenshots:
        try:
            print(f"  └ Closing Calculator #{i}")
            close_window(w)
        except Exception as e:
            print(f"    ⚠️ Error closing Calculator #{i}: {e}")

    print("✅ Done — opened all, aligned, processed + screenshotted, and closed.")

if __name__ == "__main__":
    main()
